package com.example.test_lms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestLmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestLmsApplication.class, args);
	}

}
