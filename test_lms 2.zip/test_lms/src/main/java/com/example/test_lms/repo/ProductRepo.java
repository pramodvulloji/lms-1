package com.example.test_lms.repo;

import com.example.test_lms.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepo extends JpaRepository<Product, Integer> {

    @Query("SELECT p FROM Product p WHERE " +
            "(LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR :keyword IS NULL) AND " +
            "(p.category IN :categories OR :categories IS NULL) AND " +
            "(p.model IN :models OR :models IS NULL)")
    List<Product> searchProducts(String keyword, List<String> categories, List<String> models);
}
