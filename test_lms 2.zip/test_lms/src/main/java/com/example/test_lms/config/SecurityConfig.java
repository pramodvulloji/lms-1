//package com.example.test_lms.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers("/api/products", "/api/product/{id}", "/api/products/search").permitAll() // Public access to read-only actions
//                        .requestMatchers("/api/product", "/api/products/bulk").hasRole("ADMIN") // Admin or Superadmin for creating
//                        .requestMatchers("/api/product/{id}").hasRole("ADMIN") // Admin or Superadmin for updating
//                        .requestMatchers("/api/product/{id}/delete").hasRole("SUPERADMIN") // Only Superadmin can delete
//                        .anyRequest().authenticated() // All other requests must be authenticated
//                )
//                .csrf(csrf -> csrf.disable()) // Disable CSRF protection for simplicity (can be enabled for production)
//                .httpBasic(httpBasic -> httpBasic.disable()); // Use form login or JWT for production
//        return http.build();
//    }
//    @Bean
//    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
//        return authenticationConfiguration.getAuthenticationManager();
//    }
//}
package com.example.test_lms.config;

import com.example.test_lms.security.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/api/users/login").permitAll()  // Allow login without authentication
                .antMatchers("/api/products", "/api/product/{id}", "/api/products/search").permitAll()  // Public access
                .antMatchers("/api/product", "/api/products/bulk").hasRole("ADMIN") // Admin or Superadmin
                .antMatchers("/api/product/{id}").hasRole("ADMIN") // Admin or Superadmin
                .antMatchers("/api/product/{id}/delete").hasRole("SUPERADMIN") // Only Superadmin
                .anyRequest().authenticated(); // Other requests must be authenticated

        // Add JWT filter
        http.addFilterBefore(new JwtAuthenticationFilter(jwtTokenUtil), UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class).build();
    }
}
