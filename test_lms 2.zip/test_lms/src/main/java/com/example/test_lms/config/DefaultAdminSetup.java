package com.example.test_lms.config;

import com.example.test_lms.model.User;
import com.example.test_lms.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DefaultAdminSetup implements CommandLineRunner {

    private final UserRepo userRepo;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public DefaultAdminSetup(UserRepo userRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Check if the Superadmin already exists
        if (!userRepo.existsByUsername("superadmin")) {
            // Create Superadmin user if not exists
            User superAdmin = new User();
            superAdmin.setUsername("superadmin");
            superAdmin.setPassword(passwordEncoder.encode("superadminpassword"));
            superAdmin.setRole(User.Role.SUPERADMIN);
            userRepo.save(superAdmin);
        }
    }
}
