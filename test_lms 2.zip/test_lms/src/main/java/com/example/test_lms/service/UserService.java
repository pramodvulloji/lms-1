package com.example.test_lms.service;

import com.example.test_lms.model.User;
import com.example.test_lms.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

//
//@Service
//public class UserService {
//
//    private final UserRepo userRepo;
//    private final PasswordEncoder passwordEncoder;
//
//    @Autowired
//    public UserService(UserRepo userRepo, PasswordEncoder passwordEncoder) {
//        this.userRepo = userRepo;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//    // Register new user
//    public void registerUser(User user) {
//        if (userRepo.findByUsername(user.getUsername()).isPresent()) {
//            throw new IllegalArgumentException("Username already exists");
//        }
//        user.setPassword(passwordEncoder.encode(user.getPassword()));  // Encrypt the password
//        userRepo.save(user);
//    }
//
//    // Update user's role (Only allowed for SuperAdmin)
//    public void updateUserRole(int id, String role) {
//        User user = userRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
//        if ("ADMIN".equals(role) || "USER".equals(role)) {
//            user.setRole(User.Role.valueOf(role));
//            userRepo.save(user);
//        } else {
//            throw new IllegalArgumentException("Invalid role");
//        }
//    }
//
//    // Delete user (Only allowed for SuperAdmin)
//    public void deleteUser(int id) {
//        User user = userRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
//        userRepo.delete(user);
//    }
//}
@Service
public class UserService {

    private final UserRepo userRepo;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepo userRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }

    // Register a new user
    public void registerUser(User user) {
        // Check if the user already exists by username
        if (userRepo.findByUsername(user.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }

        // Hash the user's password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Check if the role is ADMIN, then check if the current user is SUPERADMIN
        if (user.getRole() == User.Role.ADMIN) {
            // Only Superadmin can create Admins
            // You need to retrieve the currently authenticated user (Superadmin)
            User currentUser = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (currentUser.getRole() != User.Role.SUPERADMIN) {
                throw new IllegalArgumentException("Only Superadmin can create Admin users");
            }
        }

        // Save the user to the database
        userRepo.save(user);
    }

    public boolean validateLogin(String username, String password) {
        Optional<User> user = userRepo.findByUsername(username);
        if (user.isPresent()) {
            return passwordEncoder.matches(password, user.get().getPassword());
        }
        return false; // Username not found
    }
    // Update user's role (Only Superadmin can change roles)
    public void updateUserRole(int id, String role) {
        User user = userRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));

        // Ensure only valid roles can be set
        if ("ADMIN".equals(role) || "USER".equals(role)) {
            user.setRole(User.Role.valueOf(role));
            userRepo.save(user);
        } else {
            throw new IllegalArgumentException("Invalid role");
        }
    }

    // Delete user (Only Superadmin can delete users)
    public void deleteUser(int id) {
        User user = userRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
        userRepo.delete(user);
    }
}
