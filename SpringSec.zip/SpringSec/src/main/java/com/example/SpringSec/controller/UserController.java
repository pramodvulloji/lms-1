package com.example.SpringSec.controller;

import com.example.SpringSec.entity.User;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UserController {


    private List<User> users=new ArrayList<>(List.of(
            new User(1,"pramod","1234"),
        new User(2,"Vaishnavi","1234")
));


    @GetMapping("/users")
    public List<User> getUsers(){
       return users;
    }

    @GetMapping("/CSRF-TOKEN")
    public CsrfToken getToken(HttpServletRequest request)
    {
        return (CsrfToken) request.getAttribute("_csrf");
    }

    @PostMapping("/register")
    public User addUser(@RequestBody User user)
    {
        users.add(user);
        return user;
    }
}


//    private List<User> users= new ArrayList<>(List.of(
//            new User(1, "Pramod"),
//            new User(2,"Vaishnavi")
//    ));